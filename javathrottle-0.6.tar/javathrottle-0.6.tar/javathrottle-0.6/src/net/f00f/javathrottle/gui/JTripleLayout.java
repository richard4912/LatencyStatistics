package net.f00f.javathrottle.gui;

import java.awt.FlowLayout;
import java.awt.GridLayout;

/**
 * Lays out three components equally spaced
 * */
public class JTripleLayout extends GridLayout
{
	public JTripleLayout()
	{
		super( 1,3 );
	}
}
